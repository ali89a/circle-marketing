<?php

namespace Database\Factories;

use App\Models\OrderNOCInfo;
use Illuminate\Database\Eloquent\Factories\Factory;

class OrderNOCInfoFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = OrderNOCInfo::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
