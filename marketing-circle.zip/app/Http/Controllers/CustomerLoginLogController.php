<?php

namespace App\Http\Controllers;

use App\Models\CustomerLoginLog;
use Illuminate\Http\Request;

class CustomerLoginLogController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\CustomerLoginLog  $customerLoginLog
     * @return \Illuminate\Http\Response
     */
    public function show(CustomerLoginLog $customerLoginLog)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\CustomerLoginLog  $customerLoginLog
     * @return \Illuminate\Http\Response
     */
    public function edit(CustomerLoginLog $customerLoginLog)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\CustomerLoginLog  $customerLoginLog
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CustomerLoginLog $customerLoginLog)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\CustomerLoginLog  $customerLoginLog
     * @return \Illuminate\Http\Response
     */
    public function destroy(CustomerLoginLog $customerLoginLog)
    {
        //
    }
}
