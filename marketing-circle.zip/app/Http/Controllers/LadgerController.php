<?php

namespace App\Http\Controllers;

use App\Models\Ladger;
use Illuminate\Http\Request;

class LadgerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Ladger  $ladger
     * @return \Illuminate\Http\Response
     */
    public function show(Ladger $ladger)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Ladger  $ladger
     * @return \Illuminate\Http\Response
     */
    public function edit(Ladger $ladger)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Ladger  $ladger
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Ladger $ladger)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Ladger  $ladger
     * @return \Illuminate\Http\Response
     */
    public function destroy(Ladger $ladger)
    {
        //
    }
}
