<?php

namespace App\Http\Controllers;

use App\Models\OrderBuffer;
use Illuminate\Http\Request;

class OrderBufferController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\OrderBuffer  $orderBuffer
     * @return \Illuminate\Http\Response
     */
    public function show(OrderBuffer $orderBuffer)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\OrderBuffer  $orderBuffer
     * @return \Illuminate\Http\Response
     */
    public function edit(OrderBuffer $orderBuffer)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\OrderBuffer  $orderBuffer
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, OrderBuffer $orderBuffer)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\OrderBuffer  $orderBuffer
     * @return \Illuminate\Http\Response
     */
    public function destroy(OrderBuffer $orderBuffer)
    {
        //
    }
}
